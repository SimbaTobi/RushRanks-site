# RushRanks Modern Landing (Static Site)

A polished, responsive landing page you can deploy **free** with GitHub Pages, Netlify, or Cloudflare Pages.

## 1) Edit your store links (1 minute)
Open `scripts.js` and set:
```js
const APP_STORE_URL = "https://apps.apple.com/app/idYOUR_ID";
const PLAY_URL      = "https://play.google.com/store/apps/details?id=com.rushranks";
```
If left empty, the buttons default to **"Notify me"** (mailto to support@rushranks.com).

## 2) Replace placeholder badges (2 minutes)
Swap `assets/badge-appstore.svg` and `assets/badge-googleplay.svg` with the official badges from Apple/Google and follow their brand rules.

## 3) Deploy (GitHub Pages — 5 min)
- Create a repository (e.g., `rushranks-site`) and upload these files.
- In the repo: **Settings → Pages → Source: Deploy from a branch** → pick `main`.
- Your site will appear at `https://<you>.github.io/rushranks-site/`.
- To use your domain (e.g., `rushranks.com`), add a `CNAME` in **Pages** and update DNS.

> Alternatives: drag the folder into **Netlify** (it auto-deploys) or connect to **Cloudflare Pages**.

## 4) Optional polish
- **SEO:** Update `<title>` and `<meta description>` in `index.html`. Add more OpenGraph images.
- **Analytics:** Add Plausible/Cloudflare/Web Analytics script to `index.html`.
- **Email:** Change the support email in `index.html`, `privacy.html`, `terms.html` to your real inbox.
- **Legal:** Customize `privacy.html` and `terms.html` to match your actual data practices (not legal advice).

## 5) Structure
- `index.html` — landing (hero, how it works, features, Rushchive, FAQ).
- `privacy.html`, `terms.html` — starter legal pages.
- `styles.css` — design system (dark theme, glass cards, gradients).
- `scripts.js` — mobile nav, reveal-on-scroll, midnight countdown, and store link config.
- `assets/` — logo, phone mock, badge placeholders.

---

Made for RushRanks — © 2025 Sandook LLC.